package ac.il.shenkar.couponHibernet;

import java.util.Iterator;

/**
 * IBusinessDAO interface
 * @author David Faiz & Yaniv Levi
 *
 */

public interface IBusinessDAO {
	 /**
     * This method returns Business object from the  
     * database via ID number.
     * @param id                Business ID number.
     * @return                  Business instance.
     */
		   public abstract Business getBusiness(int id);
		   /**
		    * This method updates a Business object in 
		    * the a database.
		    * @param ob              Business instance to update.
		    * @return                True if update is successfull and False if Update fails.
		    */ 
		   public abstract boolean updateBusniess(Business ob);
		   /**
		    * This method returns all businesses.
		    * @return                An iterator of businesses.
		    */
		   public abstract Iterator<Coupon> getAllBusiness();
		   /**
		    * This method deletes a desired business by its id.
		    * @param id              The id number to be deleted.
		    * @return                True if deleted sucessfully.Otherwise False.
		    */
		   public abstract boolean deleteBusiness(int id);
		   /**
		    * This method adds a new business object to the database.
		    * @param ob              The business object to add.
		    * @return                True if added sucessfully.Otherwise False.
		    */   
		   public abstract boolean addBusiness(Business ob);
}
