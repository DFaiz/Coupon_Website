package ac.il.shenkar.couponHibernet;

import java.util.Collection;

/**
 * IShoppingCart interface
 * @author David Faiz & Yaniv Levi
 *
 */

//An interface to be utilizing for any shopping cart methods.

public interface IShoppingCart {
	public void addCouponToCart(Coupon coupon);
	public Collection<ShoppingCartRow> getShoppingCartRows();
}
