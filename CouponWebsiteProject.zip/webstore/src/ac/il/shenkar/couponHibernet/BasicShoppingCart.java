package ac.il.shenkar.couponHibernet;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

/**
 * BasicShoppingCart class
 * @author David Faiz & Yaniv Levi
 *
 */

public class BasicShoppingCart implements IShoppingCart
{

	Vector<ShoppingCartRow> rows = new Vector<ShoppingCartRow>(); 
	
	@Override
	public void addCouponToCart(Coupon coupon)
	{
		/*The method checks if there's already a row with this product
		and update that row (if exists) or create a new one */
		
		//Iterating all rows and finding the relevant row (if such a row exists)
		Iterator<ShoppingCartRow> iterator = rows.iterator();
		ShoppingCartRow rowToWorkOn = null;
		while(iterator.hasNext()) {
			ShoppingCartRow row = iterator.next();
			if(row.getCoupon().get_id()==coupon.get_id())
			{
				rowToWorkOn = row; 
				break;
			}
		}
		
		//Row exists
		if(rowToWorkOn!=null)
		{
			rowToWorkOn.setQuantity(rowToWorkOn.getQuantity()+1);
		}
		
		//A new row should be created
		else
		{
			ShoppingCartRow row = new ShoppingCartRow(coupon,1);
			rows.add(row);
		}
	}

	@Override
	public Collection<ShoppingCartRow> getShoppingCartRows()
	{
		/*Method returns all products*/
		return rows;
	}
}
